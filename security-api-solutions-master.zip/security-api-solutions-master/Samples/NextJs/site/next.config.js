module.exports = {
  target: 'serverless'
}