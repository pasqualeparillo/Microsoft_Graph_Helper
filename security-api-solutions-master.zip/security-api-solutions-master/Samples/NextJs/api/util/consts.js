const APIVERSION = "v1.0";
const RESTURL = "https://graph.microsoft.com/" + APIVERSION + "/";

module.exports = {
    APIVERSION,
    RESTURL
};
