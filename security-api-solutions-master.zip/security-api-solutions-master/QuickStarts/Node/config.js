module.exports = {
  appId: '<enter app/client Id>',
  appSecret: '<enter app/client secret>',
  tenantId: '<enter tenant Id>'
};